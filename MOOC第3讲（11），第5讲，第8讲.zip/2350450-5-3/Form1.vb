﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        FileOpen(1, "stud.dat", OpenMode.Output)
        WriteLine(1, "150001", "张萍", 89) : WriteLine(1, "150002", "李一凡", 87) : WriteLine(1, "150003", "黄小明", 99) : WriteLine(1, "150004", "袁冬林", 67) : WriteLine(1, "150005", "朱可湘", 78)
        FileClose()
        MsgBox("文件生成成功！请到‘2350450-5-3\bin\Debug’路径下目录查看", MsgBoxStyle.Information, "提示")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""

        Dim i%      '总人数
        Dim cj%     '各人成绩
        Dim sum%    '成绩之和

        FileOpen(1, "stud.dat", OpenMode.Input)
        Do Until EOF(1)
            Input(1, "") : Input(1, "") : Input(1, cj)
            sum += cj
            i += 1
        Loop
        FileClose()

        TextBox1.Text &= "总人数：" & i & vbCrLf
        TextBox1.Text &= "平均分：" & (sum / i)
    End Sub
End Class
