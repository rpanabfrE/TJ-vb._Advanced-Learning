﻿'得意之作，艰辛之作
'纵使困顿难行，亦当砥砺奋进
'你的算法是现代的，构思却相当古老，你究竟是什么人？

Imports System.Math
Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim g As Graphics = PictureBox1.CreateGraphics
        Dim x0! = PictureBox1.Width / 2 : Dim y0! = PictureBox1.Height / 2 : g.TranslateTransform(x0, y0)
        Dim ax! = PictureBox1.Width / 210
        PictureBox1.Refresh()

        Dim r! = (PictureBox1.Width / 2) * 0.3

        Dim pen1 As Pen = New Pen(Color.Blue, 1)
        'pen1 = New Pen(Color.FromArgb(0, 0, 255))这样也可以
        '但一定要New一个对象。不能直接pen2.color =

        '虽然是单色，仅仅一个Blue也过于单调过于简单了，因此在下方留了打开ColorDialog1的代码。
        'If ColorDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
        '    pen1.Color = ColorDialog1.Color
        'End If

        Dim n%
        If Val(TextBox1.Text) <= 0 Then
            MsgBox("请输入正确的数据n，来将圆周n等分", MsgBoxStyle.Information, "提示")
        Else
            n = Int(TextBox1.Text)
        End If

        Dim alf! = (2 * PI) / n       '圆心角（弧度制）
        Dim x(n), y(n) As Single
        For i = 1 To n
            x(i) = r * Cos(i * alf)
            y(i) = r * Sin(i * alf)
        Next

        For dog = 1 To n - 1
            For cat = dog + 1 To n
                g.DrawLine(pen1, x(dog) * ax, -y(dog) * ax, x(cat) * ax, -y(cat) * ax)
            Next
        Next

        g.Dispose()
        pen1.Dispose()
        'Dispose()
        '不要用上面注释的这个，程序会自动退出
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Text = 12
        Randomize()
        'RGB函数会自动把参数值转为整数，所以不用一一套Int
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim g As Graphics = PictureBox1.CreateGraphics
        Dim x0! = PictureBox1.Width / 2 : Dim y0! = PictureBox1.Height / 2 : g.TranslateTransform(x0, y0)
        Dim ax! = PictureBox1.Width / 210
        PictureBox1.Refresh()

        Dim r! = (PictureBox1.Width / 2) * 0.3             '圆的半径r
        Dim pen2 As Pen
        'Dim MyColor As Color

        Dim n%
        If Val(TextBox1.Text) <= 0 Then
            MsgBox("请输入正确的数据n，来将圆周n等分", MsgBoxStyle.Information, "提示")
        Else
            n = Int(TextBox1.Text)
        End If

        Dim alf! = (2 * PI) / n       '圆心角（弧度制）
        Dim x(n), y(n) As Single
        For i = 1 To n
            x(i) = r * Cos(i * alf)
            y(i) = r * Sin(i * alf)
        Next

        For dog = 1 To n - 1
            For cat = dog + 1 To n
                pen2 = New Pen(Color.FromArgb(Rnd() * 255, Rnd() * 255, Rnd() * 255))
                g.DrawLine(pen2, x(dog) * ax, -y(dog) * ax, x(cat) * ax, -y(cat) * ax)
            Next
        Next

        g.Dispose()
    End Sub
End Class
