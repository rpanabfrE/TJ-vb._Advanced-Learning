﻿Public Class Form1

    Sub MaxLength(s, MaxWord)
        s &= Space(1)
        Do While s <> ""
            Dim i = InStr(s, " ")
            Dim word = Mid(s, 1, i - 1)
            If Len(word) > Len(MaxWord) Then MaxWord = word
            s = Mid(s, i + 1)
        Loop

        TextBox2.Text = MaxWord
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim s$ = TextBox1.Text
        Dim MaxWord$ = ""
        Call MaxLength(s, MaxWord)
    End Sub
End Class
