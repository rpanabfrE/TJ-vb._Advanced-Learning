﻿Public Class Form1

    Function IsWs(m%) As Boolean
        IsWs = False    '初始化，因为非完数多，完数少，所以先默认m为非完数
        Dim sum% = 0    'sum表示m的累加因子和（因子包括1但不包括m自身）
        If m Mod 2 = 0 Then     '如果m是偶数
            For i = 1 To m / 2
                If m Mod i = 0 Then sum += i
            Next
        Else    '如果m是奇数
            For i = 1 To (m - 1) / 2
                If m Mod i = 0 Then sum += i
            Next
        End If

        If m = sum Then IsWs = True
    End Function

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = "1000以内（不含1000）的完数为：" & vbCrLf & vbCrLf

        For i = 1 To 999
            If IsWs(i) = True Then
                Label1.Text &= i & " = "
                If i Mod 2 = 0 Then     '如果这个数是偶数
                    For j = 1 To i / 2
                        If i Mod j = 0 Then Label1.Text &= j & " + "
                    Next
                Else    '如果这个数是奇数
                    For j = 1 To (i - 1) / 2
                        If i Mod j = 0 Then Label1.Text &= j & " + "
                    Next
                End If
                Label1.Text = Mid(Label1.Text, 1, Len(Label1.Text) - 3)
                Label1.Text &= vbCrLf & vbCrLf
            End If
        Next
    End Sub
End Class
