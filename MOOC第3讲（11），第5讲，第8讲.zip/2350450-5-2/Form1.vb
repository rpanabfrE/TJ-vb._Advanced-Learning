﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim fb(9) As Integer
        fb(0) = 0 : fb(1) = 1
        For i = 2 To 9
            fb(i) = fb(i - 2) + fb(i - 1)
        Next

        FileOpen(1, "fb.dat", OpenMode.Output)
        For i = 0 To 9
            WriteLine(1, i, fb(i))
        Next
        FileClose()
        MsgBox("文件生成成功！请到‘2350450-5-2\bin\Debug’路径下目录查看", MsgBoxStyle.Information, "提示")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        Dim fb%
        Dim sum% = 0
        FileOpen(1, "fb.dat", OpenMode.Input)
        For i = 0 To 9
            Input(1, "") : Input(1, fb)
            TextBox1.Text &= "Fib(" & i & ")=" & fb & vbCrLf
            sum += fb
        Next
        FileClose()
        TextBox1.Text &= "10项斐波那契数列和=" & sum
    End Sub
End Class
