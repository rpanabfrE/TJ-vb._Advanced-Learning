﻿Imports System.Math
Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click, Label1.Click, PictureBox1.Click
        Dim g As Graphics = Label1.CreateGraphics
        Dim x0, y0 As Single : x0 = Label1.Width / 2 : y0 = Label1.Height / 2 : g.TranslateTransform(x0, y0)
        Dim ax! = Label1.Width / 7
        Label1.Refresh()

        Dim border As Rectangle = New Rectangle(-x0 + 1, -(y0 - 1), Label1.Width - 3, Label1.Height - 4)
        g.DrawRectangle(Pens.Black, border)

        g.DrawLine(Pens.Blue, 0, -10 * ax, 0, 10 * ax)      'y轴
        g.DrawLine(Pens.Blue, -10 * ax, 0, 10 * ax, 0)      'x轴

        '表头、x轴坐标刻度与刻度值
        Dim f As Font = New Font("Times New Roman", 9, FontStyle.Bold)
        Dim sb As SolidBrush = New SolidBrush(Color.Black)
        g.DrawString("Y=Sin(x)", f, sb, 0.5 * ax, -(3 * ax))
        For i = -3 To 3
            g.DrawLine(Pens.Blue, i * ax, 0, i * ax, -10)
            g.DrawString(i, f, sb, i * ax, 0)
        Next

        Dim x1, y1, x2, y2 As Single
        x1 = -6.28
        y1 = Sin(x1)
        For i = -6.28 To 6.28 Step 0.001
            x2 = x1 + 0.001
            y2 = Sin(x2)
            g.DrawLine(Pens.Blue, x1 * ax, -(y1 * ax), x2 * ax, -(y2 * ax))
            x1 = x2
            y1 = y2
        Next

        g.Dispose()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.BackColor = Color.Wheat
    End Sub
End Class
