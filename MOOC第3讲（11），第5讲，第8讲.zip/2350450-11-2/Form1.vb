﻿Public Class Form1

    Dim s1$, s2$

    Sub DeleStr(s1, s2)
        Do While InStr(s1, s2) <> 0     '当s1中找不到s2，InStr函数返回0
            s1 = Mid(s1, 1, InStr(s1, s2) - 1) & Mid(s1, InStr(s1, s2) + Len(s2))
            TextBox1.Text = s1
            TextBox2.Text = ""
        Loop
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        s1 = TextBox1.Text
        s2 = TextBox2.Text
        Call DeleStr(s1, s2)
    End Sub
End Class
