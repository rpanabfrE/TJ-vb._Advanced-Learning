﻿Public Class Form4

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "a" And TextBox2.Text = 1 Then
            Form1.Show()
            Me.Hide()

        Else
            MsgBox("错误")
        End If
    End Sub
End Class