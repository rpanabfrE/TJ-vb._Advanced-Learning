﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        FileOpen(1, "ScoreP.txt", OpenMode.Output) : FileOpen(2, "ScoreW.txt", OpenMode.Output)
        PrintLine(1, "051023", "王海涛", 66) : PrintLine(1, "052498", "周文英", 88) : PrintLine(1, "050992", "陈建栋", 71)
        WriteLine(2, "051023", "王海涛", 66) : WriteLine(2, "052498", "周文英", 88) : WriteLine(2, "050992", "陈建栋", 71)
        FileClose()
        MsgBox("文件生成成功！请到‘2350450-5-1\bin\Debug’路径下目录查看", MsgBoxStyle.Information, "提示")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = "" : TextBox2.Text = ""

        Dim p As String
        FileOpen(1, "ScoreP.txt", OpenMode.Input)
        Do Until EOF(1)
            p = LineInput(1)
            TextBox1.Text &= p & vbCrLf
        Loop

        Dim xh$ = "", xm$ = "", cj%
        FileOpen(2, "ScoreW.txt", OpenMode.Input)
        Do Until EOF(2)
            Input(2, xh) : Input(2, xm) : Input(2, cj)
            TextBox2.Text &= xh & "," & xm & "," & cj & vbCrLf
        Loop
        FileClose()
    End Sub
End Class
