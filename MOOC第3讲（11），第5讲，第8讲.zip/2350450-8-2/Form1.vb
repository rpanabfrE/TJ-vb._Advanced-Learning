﻿Imports System.Math
Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click, Timer1.Tick
        Dim g As Graphics = Me.CreateGraphics
        Dim x0, y0 As Single : x0 = Me.Width / 2 : y0 = Me.Height / 2 : g.TranslateTransform(x0, y0)
        Dim ax! = Me.Width / 20
        Me.Refresh()

        Dim pen1 As Pen = New Pen(Color.Blue)
        'If ColorDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
        '    pen1.Color = ColorDialog1.Color
        'End If

        Dim r! = (Me.Width / 2) * 0.37
        '更改r值、正方形的边长，可以催生出很多意外美丽的图案
        'r = Rnd() * (Me.Width / 2)

        Dim n% = Val(TextBox1.Text)
        Dim alf! = (2 * PI) / n     '等分角
        Dim x(n), y(n) As Single : Dim wheel(n) As Rectangle        '其实可以不定义x和y两个数组，但这里为理解方便起见还是保留

        'Dim stone As Single = Rnd() * 5 * r
        For i = 1 To n
            x(i) = r * Cos(i * alf) : y(i) = r * Sin(i * alf)
            wheel(i).X = x(i) - r : wheel(i).Y = y(i) - r : wheel(i).Width = r : wheel(i).Height = r            'wheel(i) = New Rectangle(x(i) - r, y(i) - r, 2 * r, 2 * r)
            'wheel(i) = New Rectangle(x(i) - r, y(i) - r, stone, stone)
            'pen1 = New Pen(Color.FromArgb(Rnd() * 255, Rnd() * 255, Rnd() * 255))
            g.DrawEllipse(pen1, wheel(i))
        Next

        g.Dispose()
        pen1.Dispose()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize()
        Timer1.Interval = 600
        Timer1.Enabled = False      '封印
    End Sub
End Class
