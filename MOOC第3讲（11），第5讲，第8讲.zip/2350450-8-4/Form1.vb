﻿Imports System.Math
Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim g As Graphics = Label1.CreateGraphics
        Dim x0, y0 As Single : x0 = 5 : y0 = Label1.Height / 2 : g.TranslateTransform(x0, y0)
        Dim ax! = Label1.Width / 30 : Dim bx! = Label1.Height / 4     'x,y轴刻度调整，美化图像
        Label1.Refresh()

        g.DrawLine(Pens.Red, 0, -1000, 0, 1000)      'y轴
        g.DrawLine(Pens.Red, -1000, 0, 1000, 0)      'x轴
        '这里是故意没写刻度，减少麻烦

        Dim x1, y1, x2, y2 As Single
        x1 = 0
        y1 = Math.E ^ (-0.1 * x1) * Cos(x1)
        For i = 0 To 50 Step 0.001
            x2 = x1 + 0.001
            y2 = Math.E ^ (-0.1 * x1) * Cos(x1)
            g.DrawLine(Pens.Blue, x1 * ax, -(y1 * bx), x2 * ax, -(y2 * bx))
            x1 = x2
            y1 = y2
        Next

        g.Dispose()
    End Sub
End Class
