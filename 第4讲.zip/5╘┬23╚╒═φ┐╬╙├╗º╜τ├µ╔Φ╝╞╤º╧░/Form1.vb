﻿Public Class Form1

    Private Sub 打开ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 打开ToolStripMenuItem.Click, ToolStripButton1.Click, 打开图片ToolStripMenuItem.Click      '……困惑，  **打开图片ToolStripMenuItem.Click**     这个事件指的是啥，这个疑问留在这里等待解答
        '   **打开ToolStripMenuItem_Click**   这一事件，虽然提到了ToolStrip，实际上是指MenuStrip1中“文件”选项卡下“打开”按钮被点击这一事件

        OpenFileDialog1.Filter = "文本文件|*.txt|word文档|*.doc*|所有文件|*.*"
        OpenFileDialog1.FilterIndex = 3

        If OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            PictureBox1.Image = Image.FromFile(OpenFileDialog1.FileName)
        End If

    End Sub

    Private Sub 背景ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 背景ToolStripMenuItem.Click
        背景ToolStripMenuItem.Checked = Not 背景ToolStripMenuItem.Checked
        '事件是click，和check与否没有关系，朱老师只是用在这里说明一下check功能

        If ColorDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            TextBox1.BackColor = ColorDialog1.Color
        End If
    End Sub

    Private Sub 保存ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 保存ToolStripMenuItem.Click
        SaveFileDialog1.DefaultExt = "txt"
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            FileOpen(1, SaveFileDialog1.FileName, OpenMode.Output)
            Write(1, TextBox1.Text)
            FileClose()
        End If
    End Sub

    Private Sub 字体ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles 字体ToolStripMenuItem1.Click
        If FontDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            TextBox1.Font = FontDialog1.Font
        End If
    End Sub

    Private Sub 设置ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 设置ToolStripMenuItem.Click
        If Form2.ShowDialog = Windows.Forms.DialogResult.OK Then
            TextBox1.Text = Form2.RadioButton1.Checked
        End If
    End Sub

    Private Sub 帮助ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 帮助ToolStripMenuItem.Click
        Form3.Show()
    End Sub


End Class
